import json, os, subprocess, sys

def run(cmd):
    print(">>>", cmd)
    rc = subprocess.call(cmd, shell=True)
    if rc != 0:
        print("Command failed:", cmd)
        sys.exit(rc)

def main():
    os.makedirs("results", exist_ok=True)
    run("python code/maxwell_fdtd_1d.py")
    run("python code/dirac_spinor_checks.py")
    run("python code/ym_lattice_su2_demo.py")
    run("python code/ym_lattice_su3_demo.py")
    print("\nAll runs complete. See results/*.json.")

if __name__ == "__main__":
    main()
